from gray2real import *
a=[1]
for i in range (0,31):
    a.append(0)
print(gray2real(a,8))