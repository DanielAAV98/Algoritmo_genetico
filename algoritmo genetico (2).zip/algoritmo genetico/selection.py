import random
import numpy as np

def selection(fit):
    
    
    fitness_inverso = [1 / f for f in fit]
    
    total_fitness = sum(fitness_inverso)
    # Calcula la probabilidad de selección proporcional al inverso del fitness
    probabilidades = [f / total_fitness for f in fitness_inverso]
    
    # Genera un número aleatorio en el rango [0, 1]
    r = random.random()
    
    # Realiza la selección basada en la ruleta
    acumulada = 0
    for i, probabilidad in enumerate(probabilidades):
        acumulada += probabilidad
        if r <= acumulada:
            return i