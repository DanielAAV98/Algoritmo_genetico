import numpy as np
import matplotlib.pyplot as plt

from population import *
from gray2real import *
from fitness import *
from selection import *
from crossover import *
from mutation import *
from newindiv import *

def main ():
    #crear poblacion inicial
    n = 32 						#tamaño de poblacion
    g_len = 7				    #10 bits por variable
    c_len = 4*g_len					#4 variables de 10 bits cada una 
    pop = population(n,c_len,g_len) 	#poblacion inicial
    #imprimir los factores 
    print("** Algoritmo genético **")
    print("Tamaño de población:\t",n)
    print("Tamaño de cromosoma:\t",c_len," bits")
    generaciones=[]
    bestfitness=[]
    #tg = int(input("Cantidad total de generaciones:"))
    tg = 300
    for g in range(0,tg):
        fit = []
        for indiv in pop:
            fit.append(fitness(gray2real(indiv,g_len)))
        
        bestfit = np.min(fit)
        bestindex=fit.index(bestfit)
        parent0 = pop[bestindex]
        
        
        fit_index = selection(fit) 
        parent1 = pop[fit_index]
        
        
        while parent0 == parent1:
            fit_index = selection(fit) 
            parent1 = pop[fit_index]

        offspring0, offspring1 = crossover(parent0,parent1)
        
        offspring0=mutation(offspring0)
        offspring1=mutation(offspring1)
        
        fit0 =  fitness(gray2real(parent0,g_len))
        fit1 =  fitness(gray2real(parent1,g_len))
        fit2 =  fitness(gray2real(offspring0,g_len))
        fit3 =  fitness(gray2real(offspring1,g_len))
        
        newpop = []
        
        if fit2 < fit1:
            newpop.append(offspring0)
        if fit3 < fit1:	
            newpop.append(offspring1)
        if fit1 < fit2 and fit1 > fit3:
            newpop.append(parent1)
        
#         if fit2 > fit0 or fit2 > fit1:
#             newpop.append(offspring0)
#         if fit3 > fit0 or fit3 > fit1:
#             newpop.append(offspring1)
#         if fit0 > fit2 and fit0 > fit3:
#             newpop.append(parent0)
#         if fit1 > fit2 and fit1 > fit3:
#             newpop.append(parent1)
        
        #obtener al mejor minimizar

        bestfit = np.min(fit)
        bestindex=fit.index(bestfit)
        newpop.append(pop[bestindex])
        generaciones.append(g)
        bestfitness.append(bestfit)
        
        #elitismo extendido (arreglar)
        meanfit = np.mean(fit)
        stddevfit = np.std(fit)
        for i in range (0,n):
            if fit[i] < meanfit - stddevfit:
                newpop.append(pop[i])
        
        while(len(newpop)< n):
            newpop.append(newindiv(c_len,g_len))
        pop = newpop
    
    bestfit = np.min(fit)
    bestindex=fit.index(bestfit)
    Rb=gray2real(pop[bestindex],g_len)
    

    print("el mejor individuo es: ")
    print("Min error: \t", np.min(fit))
    print("W: \t\t", Rb[0])
    print("L: \t\t", Rb[1])
    print("Ws: \t\t", Rb[2])
    print("Ls: \t\t", Rb[3])
    print("Resistencia: \t", resistencia(Rb,0))
    #r1=W, r2=L, r3=Ws, r4=Ls
    print("-----------------------------------------------------------------------------")
    
    resistencia(gray2real(pop[bestindex],g_len),1)
    plt.figure(2)
    plt.plot(generaciones, bestfitness)
    plt.title("Desempeño de las generaciones")
    plt.xlabel("Generación")
    plt.ylabel("Error cuadrático")
    plt.legend()
    plt.show()
main()