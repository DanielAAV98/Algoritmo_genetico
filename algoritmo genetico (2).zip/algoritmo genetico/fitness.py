from matplotlib import pyplot as plt

def leer_txt(VR_vs_VGS_data):
    VGS = []
    VR=[]
    with open(VR_vs_VGS_data, 'r') as file:
        for line in file:	
            line = line.strip()  # Eliminar espacios en blanco y saltos de línea
            if line:  # Ignorar líneas vacías
                columns = line.split()  # Separar las columnas por espacios en blanco
                if len(columns) == 2:  # Asegurarse de que haya exactamente dos columnas
                    VGS_dato = float(columns[0])  # Convertir el valor de la primera columna a float
                    VR_dato = float(columns[1])  # Convertir el valor de la segunda columna a float
                    VGS.append(VGS_dato)  # Agregar los valores
                    VR.append(VR_dato)
    return VGS,VR
def fitness(R):
    beta = 4.5e-6
    W = R[0]
    L = R[1]    
    VGS,Valor_esperado=leer_txt("VR_vs_VGS_data.txt")
    VTH = 0.69
    VDS = 5
    Ws = R[2]
    Ls = R[3]
    cc = ((Ls-1)*2)+((Ws/2)-2)*(Ls-2) 
    ce = (Ws-1)
    Re = cc*25+ce*(2/3)*25
    Palito_raro = 0.01
    error=0
    Vres=[]
    for i in range (0,len(VGS)):
        Id = ((beta*W)/(2*L))*((VGS[i]-VTH)**2)*(1+(Palito_raro*VDS))
        Vr = Id*Re
        error += ((Valor_esperado[i]-Vr)**2)
    error=(error/(len(VGS)))*100
    return error

def resistencia(R,graf):
    beta = 4.5e-6
    W = R[0]
    L = R[1]    
    VGS,Valor_esperado=leer_txt("VR_vs_VGS_data.txt")
    VTH = 0.69
    VDS = 5
    Ws = R[2]
    Ls = R[3]
    cc = ((Ls-1)*2)+((Ws/2)-2)*(Ls-2) 
    ce = (Ws-1)
    Re = cc*25+ce*(2/3)*25
    Palito_raro = 0.01
    error=0
    Vres=[]
    for i in range (0,len(VGS)):
        Id = ((beta*W)/(2*L))*((VGS[i]-VTH)**2)*(1+(Palito_raro*VDS))
        Vr = Id*Re
        Vres.append(Vr)
    if (graf==1):
        plt.figure(1)
        plt.plot(VGS,Vres, label='Voltaje Vr real')
        plt.plot(VGS,Valor_esperado, label='Voltaje Vr esperado')
        plt.title("Vr")
        plt.xlabel("Voltaje VGS")
        plt.ylabel("Voltaje VR")
        plt.legend()
    return Re
