def gray2real(indiv,g_len):
    g1 = indiv[0 : g_len] 			    
    g2 = indiv[g_len : (g_len*2)]		
    g3 = indiv[(g_len*2) : (g_len*3)]	
    g4 = indiv[(g_len*3) : (g_len*4)]   
    
    b1 = [g1[0]]
    b2 = [g2[0]]
    b3 = [g3[0]]
    b4 = [g4[0]]
    
    for i in range(0,g_len-1):
        b1.append(int(b1[i])^int(g1[i+1]))
        b2.append(int(b2[i])^int(g2[i+1]))
        b3.append(int(b3[i])^int(g3[i+1]))
        b4.append(int(b4[i])^int(g4[i+1]))
    d1 = 0
    d2 = 0
    d3 = 0
    d4 = 0
    
    for i in range(len(b1)):
        d1 += b1[i]*(2**((g_len-1)-i))
        d2 += b2[i]*(2**((g_len-1)-i))
        d3 += b3[i]*(2**((g_len-1)-i))
        d4 += b4[i]*(2**((g_len-1)-i))

    r1 = (d1+4)*0.5
    r2 = (d2+2)*0.5
    r3 = d3+1
    r4 = d4+1
    
    #r1=W, r2=L, r3=Ws, r4=Ls
    R = [r1,r2,r3,r4]
    
    return R
