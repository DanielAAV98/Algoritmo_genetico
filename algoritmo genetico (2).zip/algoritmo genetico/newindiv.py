import random
from fitness import *
from gray2real import *

def newindiv(c_len,g_len):
    while True:
        indiv=[]
        for i in range (0,c_len):
            if random.random() > 0.5:
                indiv.append(1)
            else:
                indiv.append(0)
        R=gray2real(indiv,g_len)
        if (R[0]>2*R[1]) and (R[0]<3*R[1]) and (((R[2])/R[3])<1.5) and (R[3]/(R[2])<1.5) and (R[2]%2!=0) and (resistencia(R,0)<30000):
            break
    return indiv