import numpy as np
import matplotlib.pyplot as plt

from population import *
from gray2real import *
from fitness import *
from selection import *
from crossover import *
from mutation import *
from newindiv import *

def main ():
    #crear poblacion inicial
    n = 64						#tamaño de poblacion
    g_len = 10					#10 bits por variable
    c_len = 30					#3 variables de 10 bits cada una 
    pop = population(n,c_len,g_len) 	#poblacion inicial
    #imprimir los factores 
    print("** Algoritmo genético **")
    print("Tamaño de población:\t",n)
    print("Tamaño de cromosoma:\t",c_len," bits")
    #print("Población inicial:\n",pop)
    
    #tg = int(input("Cantidad total de generaciones:"))
    tg = 60
    print("Número de generaciones:\t",tg)
    for g in range(0,tg):
        fit = []
        for indiv in pop:
            fit.append(fitness(gray2real(indiv,g_len)))
        #print("fit:\n",fit)
        #print("maxfit:\t\t",np.max(fit))
        #print("minfit:\t\t",np.min(fit))
        #print("meanfit:\t",np.mean(fit))
        #print("std_dev_fit:\t",np.std(fit))
        
        fit_index = selection(fit) 
        parent0 = pop[fit_index]
        
        
        #print("fit_index: ",fit_index)
        #print(parent0)
        
        fit_index = selection(fit) 
        parent1 = pop[fit_index]
        
        while parent0 == parent1:
            fit_index = selection(fit) 
            parent1 = pop[fit_index]
            
        #print("fit_index: ",fit_index)
        #print(parent1)
        
        offspring0, offspring1 = crossover(parent0,parent1)
        
        offspring0=mutation(offspring0)
        offspring1=mutation(offspring1)
        
        #print("off0:\n",offspring0,"\noff1:\n",offspring1)
        
        #-------------------------------------------------------------------------------
        
        fit0 =  fitness(gray2real(parent0,g_len))
        fit1 =  fitness(gray2real(parent1,g_len))
        fit2 =  fitness(gray2real(offspring0,g_len))
        fit3 =  fitness(gray2real(offspring1,g_len))
        
        newpop = []
        
        if fit2 > fit0 or fit2 > fit1:
            newpop.append(offspring0)
        if fit3 > fit0 or fit3 > fit1:
            newpop.append(offspring1)
        if fit0 > fit2 and fit0 > fit3:
            newpop.append(parent0)
        if fit1 > fit2 and fit1 > fit3:
            newpop.append(parent1)
            
#         #obtener al mejor maximizar
#         bestfit = np.max(fit)
#         bestindex=fit.index(bestfit)
#         newpop.append(pop[bestindex])
        
        #obtener al mejor minimizar
        bestfit = np.min(fit)
        bestindex=fit.index(bestfit)
        newpop.append(pop[bestindex])
        
        #elitismo extendido (arreglar)
#         meanfit = np.mean(fit)
#         stddevfit = np.std(fit)
#         for i in range (n):
#             if fit[i] > meanfit + stddevfit:
#                 newpop.append(pop[i])
        
        while(len(newpop)< n):
            newpop.append(newindiv(c_len,g_len))
        pop = newpop
    
    print("Max: ", np.max(fit))
    bestfit = np.max(fit)
    bestindex=fit.index(bestfit)
    print("el mejor individuo es: ", gray2real(pop[bestindex],g_len))
    print("-----------------------------------------------------------------------------")
for i in range(0,20):
    main() 